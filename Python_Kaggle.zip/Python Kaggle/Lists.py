# Lists
#------------------#
primes = [2,3,5,7,11];
planets = ["Mercury", "Venus", "Earth", "Mars","Jupiter","Saturn","Uranus","Neptune"];
letters = [
    ['A', 'B', 'C'],
    ['D', 'E', 'F'],
    ['G', 'H', 'J'], # (Comma after the last element is optional)
];
fav = [26,"Family",help];

# Indexing
#------------------#
print(planets[0]) # First planet which is Mercury
print(planets[1])
#Elements at the end of the list can be accessed with negative numbers, starting from -1:
print(planets[-1])
print(planets[-2])

# Slicing
#------------------#
print(planets[0:3])
#The starting and ending indices are both optional. If I leave out the start index, 
#it's assumed to be 0. starting from index 0 and continuing up to but not including index 3.
print(planets[:3])
#If I leave out the end index, it's assumed to be the length of the list.
print(planets[3:])
# All the planets except the first and last
print(planets[1:-1])
# The last 3 planets
print(planets[-3:])

# Changing Lists
#------------------#
planets[3] = "DDA";
print(planets)
planets[:3] = ["Mer", "Ven", "Ear"];
print(planets)
planets[:3] = ["Mercury", "Venus", "Earth"];
print(planets)

# List Functions
#------------------#
#len gives the length of a list
print(len(planets))
## The planets sorted in alphabetical order
print(sorted(planets))
print(sum(primes))
print(max(primes))
print(min(primes))

# Interlude Objects
#------------------#
#In short, objects carry some things around with them. You access that stuff 
#using Python's dot syntax.
x = 7;
print(x.imag)
y = 16 + 26j;
print(y.imag)
#The things an object carries around can also include functions. A function
#attached to an object is called a method.
#The things an object carries around can also include functions. A function 
#attached to an object is called a method.
print(x.bit_length) 
print(x.bit_length()) #To actually call it, we add parantheses 
help(x.bit_length)

# List Methods
#------------------#
#list.append modifies a list by adding an item to the end
planets.append("Pluto");
help(planets.append)
print(planets)
#list.pop removes and returns the last element of a list
planets.pop #Answer is Pluto

#Searching Lists
#------------------#
planets.index("Earth")
print("Pluto" in planets)
print("Ahmet" in planets)
help(planets)

#Tuples
#------------------#
# Tuples are almost exactly the same as lists. They differ in just two ways:
#*** 1: The syntax for creating them uses parentheses instead of square brackets
t = (13,16,26)
y = 16,16,26
#*** 2: They cannot be modified (they are immutable)
""" t[0] = 100 cannot be worked fine """
a = 0.375
print(a.as_integer_ratio)
numerator, denominator = a.as_integer_ratio()
print(numerator / denominator)
#In Python, != is an inequality operator that checks if two values are not equal. 
#It returns True if the values are different and False if they are equal.