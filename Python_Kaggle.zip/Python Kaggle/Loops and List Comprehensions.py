# Loops
#------------------#

# For Loops
#------------------#
planets = ['Mercury', 'Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune'];
# The for loop specifies:
# The variable name to use (in this case, planet)
# The set of values to loop over (in this case, planets)
multiplicands = (2, 2, 2, 3, 3, 5)
product = 1
for mult in multiplicands:
    product = product * mult
print(product)
# You can even loop through each character in a string
s = 'steganograpHy is the practicE of conceaLing a file, message, image, or video within another fiLe, message, image, Or video.'
msg = ''
# Print all the uppercase letters in s, one at a time
for char in s:
    if char.isupper():
        print(char, end='')       
for i in range(5):
    print("Doing important work. i =", i)
    
# While Loops
#------------------#
i = 3
while i < 10:
    print(i, end=' ')
    i += 1 # increase the value of i by 1
    
# List Comprehensions
#------------------#
squares = [n**2 for n in range(10)]
print(squares)
#Here's how we would do the same thing without a list comprehension:
squares2 = []
for n2 in range(10):
    squares2.append(n2**2)
print(squares2)
short_planets = [planet for planet in planets if len(planet) < 6]
print(short_planets)
# str.upper() returns an all-caps version of a string
loud_short_planets = [planet.upper() + '!' for planet in planets if len(planet) < 6]
print(loud_short_planets)
# Any Function is important

def count_negatives(nums):
    n_negative = 0
    for num in nums:
        if num<0:
            n_negative = n_negative + 1
    return n_negative
print(count_negatives([-5,1,-2,0,3]))
# You can easily write it with use list comprehension
def count_negatives2(nums2):
    return len([num for num in nums2 if num < 0])
print(count_negatives2([-5,-1,-2,0,-3]))
# Shorter way than all of them is:
def count_negatives3(nums3):
    return sum([num < 0 for num in nums3])
print(count_negatives3([5,-1,-2,0,-3]))