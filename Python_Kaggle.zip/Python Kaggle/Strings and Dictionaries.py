#--- Strings & Dictionaries ---#

#--- Strings ---#
x = "Pluto is a planet!"
y = 'Pluto is a planet!'
print(x==y)
print("Türkiye's in the Europe!")
print('Southeast Europe Includes "Türkiye" too!')
print('Gezeravci\'s Spaceship went to ISS at 3.15PM')
# You can save all the extra ' ' and " " with using \ (backslash), For instance
# \' = '       \" = "       \\ = \       \n = [] 
hello = "Hello from\nDobruchTurks"
print(hello)
# Python's triple quote syntax for strings lets us include newlines literally 
#(i.e. by just hitting 'Enter' on our keyboard, rather than using the special '\n' sequence).
triple_quoted_hello = """Bilecik is the
birthtown of the Ottoman Empire"""
print(triple_quoted_hello)
print(triple_quoted_hello == hello)
print('I ')
print(' Love\nyou')
#The print() function automatically adds a newline character unless we specify 
#a value for the keyword argument end other than the default value of '\n':
print("Jack")
print("& Jill")
print("Jack & ", end='')
print("Jill", end='')
#-----------------------#
president = 'Ataturk'
print(president[0])
print(president[-4:])
print(len(president))
# You can create even a loop
print([char+'! ' for char in president])
#-----------------------#
sec = "Second Mission will be Moon!"
print(sec.upper()) 
print(sec.lower())
# # Searching for the first index of a substring
print(sec.index('Moon!'))
print(sec.endswith("Moon!"))
print(sec.endswith("Moon"))
words = sec.split()
print(words)
date = '2023-07-13'
year,month,day = date.split('-')
print('-'.join([month, day, year]))
print('/'.join([month, day, year]))
print(' 👏 '.join([word.upper() for word in words]))
print(president + ' is the father of Turks')
position = 1
print(president + ' is the ' + str(position) + 'st president of Türkiye Republic')
#Only .format codes are not included

#--- Dictionaries ---#
numbers = {'one':1,'two':2,'three':3,'twenty-six':26}
print(numbers['one'])
print(numbers['twenty-six'])
# We can use the same syntax to add another key, value pair
numbers['thirty-eight'] = 38
print(numbers)
#Or to change the value associated with an existing key
numbers['one'] = 'Eskisehir'
print(numbers)
planets = ['Mercury', 'Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune']
planet_to_initial = {planet: planet[0] for planet in planets}
print(planet_to_initial)
print('Saturn' in planet_to_initial)
print('Eskisehir' in planet_to_initial)
