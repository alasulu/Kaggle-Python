x = True
print(x)
print(type(x))

#-#-# Booleans #-#-#

# a == b, a equal to b
# a < b, a less than b
# a <= b a less than or equal to b
# a != b a not equal to b
# a > b a greater than b
# a >= b a greater than or equal to b

def can_run_for_president(age):
    """Can someone of the given age run for president in the US?"""
    # The US Constitution says you must be at least 35 years old
    return age >= 35

print("Can a 26-year-old run for president?", can_run_for_president(26))
print("Can a 45-year-old run for president?", can_run_for_president(45))
##############################
3.0 == 3 # True, float == integer
"3" == 3 # False, str not == integer
##############################
def is_even(n):
    return (n%2) == 0

print("Is 77 a even number?", is_even(77))
print("Is 98 a even number?", is_even(98))
# You can combine boolean values using the standard concepts of "and", "or", 
# and "not". In fact, the words to do this are: and, or, and not.

def can_run_for_tr_president(age, natural_citizen):
    return (age >= 40) and natural_citizen

print("Can I run for the being president?", can_run_for_tr_president(27,True))
print("Can I run for the being president?", can_run_for_tr_president(54,True))
print("Can I run for the being president", can_run_for_tr_president(38,False))
print("Can I run for the being president", can_run_for_tr_president(74,False))

#-#-# Conditionals #-#-#

# Booleans are most useful when combined with conditional statements, using the 
# keywords if, elif, and else.

def inspect(x):
    if x > 0:
        print(x , "is positive number.")
    elif x == 0:
        print(x, "has the value of zero.")
    elif x < 0:
        print(x, "is negative number.")
    else:
        print(x, "is not a number perhaps")
        
inspect(4)
inspect(-9)
inspect(0)

# Note especially the use of colons (:) and whitespace to denote separate 
# blocks of code. This is similar to what happens when we define a function - 
# the function header ends with :,

def f(x):
    if x > 0:
        print("Only printed when x is positive; x =", x)
        print("Also only printed when x is positive; x =", x)
    print("Always printed, regardless of x's value; x =", x)
    
f(1)
f(0)

# Syntax of first two print function and last print function, the first two 
# print function is connected with if function, the last one is not connected.
# That's why it's printed all time.
print(bool(1)) # all numbers are treated as true, except 0
print(bool(0))
print(bool("asf")) #all strings are treated as true, except the empty string
print(bool(""))

# We can use non-boolean objects in if conditions and other places where a 
# boolean would be expected. Python will implicitly treat them as their
# corresponding boolean value:
if 0:
    print(0)
elif "spam":
    print("spam")
    
# Example 1
def sign(x):
    if x > 0:
        return 1
    elif x < 0:
        return -1
    else:
        return 0
    
# Example 2