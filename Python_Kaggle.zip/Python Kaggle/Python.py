#help(round)
#help(round(-2.04))


#Function 1
def least_difference(a,b,c):
    """Return the smallest difference between any two numbers
among a, b and c.

For instance, 
>>> least_difference(1, 5, -5)
= 4
"""
    diff1 = abs(a-b)
    diff2 = abs(b-c)
    diff3 = abs(a-c)
    return min(diff1,diff2,diff3);
print(least_difference(3, 5, 4));
print(least_difference(77, 42, 94));
print(least_difference(45, 57, 32));
#The docstring is a triple-quoted string (which may span multiple lines) that 
#comes immediately after the header of a function. When we call help() on a 
#function, it shows the docstring.


#Function 2 (MY FUNCTION)
def absolute_taker(x):
    """ Return the absolute value of the any input without using abs function
    For instance 
    >>> absolute_taker(-5) = 5 """
    if x>=0:
        return x
    else:
        return -x
A= absolute_taker(-48)
B = absolute_taker(76)
print(A)
print(B)
help(least_difference);
help(absolute_taker);


#Function 3 (MY FUNCTION)
def Chat_TR(inp):
    if inp == "Hi":
        return print("Hello then")
    if inp == "Good Morning":
        return print("Good morning buddy! How can I help you?")
    if inp == "Bye":
        return print("Bye!")
Chat_TR("Hi")
Chat_TR("Good Morning")
Chat_TR("Bye")
mystery = print()
print(mystery)

print( 5, 10, 25, sep='<')
print(5, 10, 25) #Sep has actually ' ' (single space) value.

#Function 4
def greet(who="Colin!"):
    print("Hello", who)
    
greet()
greet(who="Kaggle!")
greet(who="Alasulu!")

#Functions 5
def mult_by_five(x):
    return 5*x

def call(fn,arg):
    """Call fn on arg"""
    return fn(arg)

def squared_call(fn,arg):
    """Call fn on the result of fn on arg"""
    return fn(fn(arg))
print(
    call(mult_by_five, 3),
    squared_call(mult_by_five, 3), 
    sep='\n', # '\n' is the newline character - it starts a new line
)

#Function 6
def mod_6(x):
    """Return the remainder of x after dividing by 5"""
    return x % 6

print(
    "Which number is the biggest?",
    max(100,102,14),
    "Which number is the biggest with modulo 6?",
    max(100,51,14, key=mod_6),
    sep='\n'
)

#Function 7
def round_to_two_places(num):
    """Return the given number rounded to two decimal places. 
    
    >>> round_to_two_places(3.14159)
    3.14
    """
    pass
    return round(num,2)

finland = 338424
greenland = 2166086
print(round(finland,-3))
print(round(greenland,-2))
# As you've seen, ndigits=-1 rounds to the nearest 10, ndigits=-2 rounds to the
# nearest 100 and so on. Where might this be useful? Suppose we're dealing with
# large numbers:
    
#Function 8
def to_smash(total_candies,friends=3):
    """Return the number of leftover candies that must be smashed after distributing
    the given number of candies evenly between 3 friends.
    
    >>> to_smash(91)
    1
    """
    return total_candies % friends

print(to_smash(70,4))
print(to_smash(70,))