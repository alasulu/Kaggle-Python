#--- Working with External Libraries ---#

# Imports
import math
print("It's math! It has type {}".format(type(math)))
print(dir(math))
print("pi to 4 significant digits = {:.4}".format(math.pi))
print(math.log(32,2))
#help(math.log)
#help(math)

# Other Import Syntax
import math as mt
print(mt.pi)
from math import *
print(pi, log(32,2))
# import * makes all the module's variables directly accessible to you (without any dotted prefix).
# Bad news: some purists might grumble at you for doing this.
from math import log, pi
from numpy import asarray
# Submodules
import numpy
print("numpy.random is a", type(numpy.random))
#print("it contains names such as...",
      #dir(numpy.random)[-15:])
rolls = numpy.random.randint(1,6,5)
print(rolls)
print(type(rolls))
#print(dir(rolls))
print(rolls.mean)
print(rolls.tolist)
print(rolls+10)
print(rolls <= 3)
xlist = [[1,2,3],[4,5,6]]
x = numpy.asarray(xlist)
#help(asarray)
#help('FORMATTING')
print("xlist = {}\nx =\n{}".format(xlist,x))
## Get the last element of the second row of our numpy array
print(x[-1,1])
import tensorflow as tf
a = tf.constant(1)
b = tf.constant(1)
print(a+b)
